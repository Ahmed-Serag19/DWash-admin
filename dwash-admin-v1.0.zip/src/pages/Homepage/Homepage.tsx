import HomepageLinks from "@/components/HomepageLinks";

const Homepage = () => {
  return (
    <div>
      <HomepageLinks />
    </div>
  );
};

export default Homepage;
